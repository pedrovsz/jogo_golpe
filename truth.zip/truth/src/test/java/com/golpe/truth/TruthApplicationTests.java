package com.golpe.truth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruthApplicationTests {

	@Test
	void contextLoads() {
	}

}
