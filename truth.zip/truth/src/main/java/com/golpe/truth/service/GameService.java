package com.golpe.truth.service;

import com.golpe.truth.model.*;
import com.golpe.truth.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class GameService {

    @Autowired private QuestionRepository questionRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private RankingRepository rankingRepository;

    public Question getRandomQuestion() {
        return questionRepository.findRandomQuestion()
                .orElseThrow(() -> new RuntimeException("Nenhuma pergunta encontrada no banco"));
    }

    public User loginOrRegister(String username) {
        return userRepository.findByUsername(username)
                .orElseGet(() -> {
                    User newUser = new User();
                    newUser.setUsername(username);
                    newUser.setTotalScore(0);
                    newUser.setGamesPlayed(0);
                    return userRepository.save(newUser);
                });
    }

    public void saveScore(String username, int newTotalScore) {
        User user = loginOrRegister(username);
        
        // Atualiza usuário
        user.setTotalScore(newTotalScore);
        user.setGamesPlayed(user.getGamesPlayed() + 1);
        userRepository.save(user);

        // Registra no histórico de ranking (Log)
        RankingLog log = new RankingLog();
        log.setUsername(username);
        log.setScore(newTotalScore);
        log.setDate(LocalDateTime.now());
        rankingRepository.save(log);
    }

    public List<RankingLog> getLeaderboard() {
        return rankingRepository.findTop20ByOrderByScoreDesc();
    }
}