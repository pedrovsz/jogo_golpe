package com.golpe.truth.repository;

import com.golpe.truth.model.RankingLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RankingRepository extends JpaRepository<RankingLog, Long> {
    // Top 20 melhores pontuações
    List<RankingLog> findTop20ByOrderByScoreDesc();
}