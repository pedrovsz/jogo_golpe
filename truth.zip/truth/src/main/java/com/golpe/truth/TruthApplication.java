package com.golpe.truth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruthApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruthApplication.class, args);
	}

}
