package com.golpe.truth.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "questions")
@Data
public class Question {
    @Id
    private String id; // Ex: "premio-falso-001"

    private String title;
    private String difficulty;

    // Armazenando arrays de Strings simples
    @ElementCollection
    private java.util.List<String> tags;

    @ElementCollection
    private java.util.List<String> variants;

    // Armazenando objetos complexos como JSON String (TEXT)
    // No front, ao receber, o Jackson fará o parse se configurado, 
    // ou enviamos como String e o Front faz JSON.parse
    @Column(columnDefinition = "TEXT")
    private String dialogJson; 

    @Column(columnDefinition = "TEXT")
    private String optionsJson;
}