package com.golpe.truth.controller;

import com.golpe.truth.model.*;
import com.golpe.truth.service.GameService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Permite acesso do React
public class GameController {

    @Autowired
    private GameService gameService;

    @Autowired
    private ObjectMapper objectMapper;

    // Endpoint: Login
    @PostMapping("/auth/login")
    public User login(@RequestBody Map<String, String> payload) {
        return gameService.loginOrRegister(payload.get("username"));
    }

    // Endpoint: Pegar pergunta aleatória
    @GetMapping("/questions/random")
    public Map<String, Object> getRandomQuestion() {
        Question q = gameService.getRandomQuestion();
        // Convertemos as Strings JSON de volta para Objetos Java para enviar um JSON limpo ao front
        try {
            Map<String, Object> response = objectMapper.convertValue(q, Map.class);
            response.put("dialog", objectMapper.readTree(q.getDialogJson()));
            response.put("options", objectMapper.readTree(q.getOptionsJson()));
            return response;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao processar JSON da pergunta");
        }
    }

    // Endpoint: Salvar Pontuação
    @PostMapping("/scores")
    public void saveScore(@RequestBody Map<String, Object> payload) {
        String username = (String) payload.get("username");
        Integer score = (Integer) payload.get("score");
        gameService.saveScore(username, score);
    }

    // Endpoint: Ranking
    @GetMapping("/ranking")
    public List<RankingLog> getRanking() {
        return gameService.getLeaderboard();
    }
}